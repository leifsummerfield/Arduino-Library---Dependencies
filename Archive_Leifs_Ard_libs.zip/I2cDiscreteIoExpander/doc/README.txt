Documentation is available at:
  http://4-20ma.github.com/I2cDiscreteIoExpander

Alternatively, you can download the HTML files at:
  [tarball] https://github.com/4-20ma/I2cDiscreteIoExpander/tarball/gh-pages
  [zipball] https://github.com/4-20ma/I2cDiscreteIoExpander/zipball/gh-pages
